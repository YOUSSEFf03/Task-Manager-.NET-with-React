using System;
using System.ComponentModel.DataAnnotations;

namespace Final_Project_Backend.Models
{
   public class Attachment
{
    [Key]
    public string AttachmentId { get; set; } = Guid.NewGuid().ToString();
    public string TaskId { get; set; } = null!;
    public string UploadedByUserId { get; set; } = null!;
    public string FileName { get; set; } = null!;
    public string FileUrl { get; set; } = null!;
    public DateTime UploadedAt { get; set; }

    public Task Task { get; set; } = null!;
    public User UploadedByUser { get; set; } = null!;
}
}
